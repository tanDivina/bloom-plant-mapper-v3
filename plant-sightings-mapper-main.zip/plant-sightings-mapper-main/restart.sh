#!/bin/bash

echo "🧹 Clearing Metro cache..."
npx expo start --clear

echo "✅ Metro cache cleared and server restarted!"